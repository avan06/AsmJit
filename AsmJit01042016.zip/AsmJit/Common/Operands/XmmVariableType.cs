namespace AsmJit.Common.Operands
{
	internal enum XmmVariableType
	{
		Xmm = 14,
		XmmSs = 15,
		XmmPs = 16,
		XmmSd = 17,
		XmmPd = 18
	}
}