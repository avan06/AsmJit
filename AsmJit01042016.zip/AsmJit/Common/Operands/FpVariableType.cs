namespace AsmJit.Common.Operands
{
	internal enum FpVariableType
	{
		Fp32 = 10,
		Fp64 = 11
	}
}