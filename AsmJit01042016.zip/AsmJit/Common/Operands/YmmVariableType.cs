namespace AsmJit.Common.Operands
{
	internal enum YmmVariableType
	{
		Ymm = 19,
		YmmPs = 20,
		YmmPd = 21
	}
}