namespace AsmJit.Common.Operands
{
	internal enum ZmmVariableType
	{
		Zmm = 22,
		ZmmPs = 23,
		ZmmPd = 24
	}
}