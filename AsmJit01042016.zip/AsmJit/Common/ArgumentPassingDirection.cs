namespace AsmJit.Common
{
	internal enum ArgumentPassingDirection
	{
		LeftToRight = 0,
		RightToLeft = 1
	}
}